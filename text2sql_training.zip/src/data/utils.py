SQL_SPECIAL_TOKENS = {
    'schema': '<|schema|>',
    'query': '<|query|>',
    'sql': '<|sql|>',
    'endoftext': '<|endoftext|>',
}

STOP_WORDS = [';', ');', '\';', '";', '<|endoftext|>']